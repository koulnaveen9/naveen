package com.example.vac.optiwist;

/**
 * Created by vac on 8/27/2016.
 */
public class FormModel {
    private String rollno;
    private String studentname;
    private String studentclass;
    private String address;
    private String contacts;

    public String getRollno() {
        return rollno;
    }
    public void setRollno(String rollno){
        this.rollno=rollno;
    }
    public String getStudentname(){
        return studentname;
    }
    public void setStudentname(String studentname){
        this.studentname=studentname;
    }
    public String getStudentclass() {
        return studentclass;
    }
    public void setStudentclass(String studentclass){
        this.studentclass=studentclass;
    }
    public String getAddress(){
        return address;
    }
    public void setAddress(String address){
        this.address=address;
    }
    public String getContacts(){
        return contacts;
    }
    public void setContacts(String contacts){
        this.contacts=contacts;
    }
}
