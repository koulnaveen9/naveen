package com.example.vac.optiwist;


import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.vac.optiwist.FormModel;
import com.example.vac.optiwist.R;

import java.util.ArrayList;

public class FormAdapter extends ArrayAdapter<FormModel> {
    private Context context;
    private ArrayList<FormModel> formModelList;

    public FormAdapter(Context context, ArrayList<FormModel> formModelList) {
        super(context, R.layout.activity_form_adapter, formModelList);
        this.context = context;
        this.formModelList = formModelList;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.activity_form_adapter, parent, false);
        TextView tvRollNO = (TextView) view.findViewById(R.id.itemrollno);
        TextView tvStudentName = (TextView) view.findViewById(R.id.itemname);
        TextView tvStudentclass = (TextView) view.findViewById(R.id.itemclass);
        TextView tvAddress= (TextView) view.findViewById(R.id.itemaddress);
        TextView tvContacts = (TextView) view.findViewById(R.id.itemcontacts);
        tvRollNO.setText((formModelList.get(position).getRollno()));
        tvStudentName.setText((formModelList.get(position).getStudentname()));
        tvStudentclass.setText((formModelList.get(position).getStudentclass()));
        tvAddress.setText((formModelList.get(position).getAddress()));
        tvContacts.setText((formModelList.get(position).getContacts()));


        return view;
    }


}
