package com.example.vac.optiwist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener{
    private Button insert,delete,update,view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        insert=(Button)findViewById(R.id.insert);
        delete=(Button)findViewById(R.id.delete);
        update=(Button)findViewById(R.id.update);
        view=(Button)findViewById(R.id.view);
        insert.setOnClickListener(this);
        delete.setOnClickListener(this);
        update.setOnClickListener(this);
        view.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.insert:
                goToRegistration();
                break;
            case R.id.delete:
                goToDelete();
            case R.id.update:
                goToUpdate();
        }


    }

    private void goToUpdate() {
        Toast.makeText(getApplicationContext(),"Record is updated",Toast.LENGTH_LONG).show();
    }

    private void goToDelete() {
        Toast.makeText(getApplicationContext(),"Record is deleted",Toast.LENGTH_LONG).show();
    }

    private void goToRegistration() {
        Intent intent=new Intent(this,Formregistration.class);
        startActivity(intent);
    }
}
