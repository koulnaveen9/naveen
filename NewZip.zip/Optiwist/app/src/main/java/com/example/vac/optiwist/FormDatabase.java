package com.example.vac.optiwist;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import static  com.example.vac.optiwist.Constants.*;

/**
 * Created by vac on 6/16/2016.
 */
public class FormDatabase extends SQLiteOpenHelper {
    String query ="CREATE TABLE " + TABLE_NAME + "("
            + ROLLNO       + " TEXT NOT NULL, "
            + STUDENTNAME  + " TEXT NOT NULL, "
            + STUDENTCLASS  + " TEXT NOT NULL, "
            + ADDRESS        + " TEXT NOT NULL,"
            + CONTACTS        +"TEXT NOT NULL);";
    public FormDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);


    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

}
