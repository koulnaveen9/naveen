package com.example.vac.optiwist;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ListView;

import com.example.vac.optiwist.FormDatabase;

import java.util.ArrayList;

import static com.example.vac.optiwist.Constants.TABLE_NAME;

public class DetaillList extends Activity {
    private GridView adapter;
    private ArrayList<FormModel> formModelList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detaill_list);
        adapter=(GridView)findViewById(R.id.adapter);

        getValueFromDatabase();
        adapter.setAdapter(new FormAdapter(this,formModelList));

    }

    private void getValueFromDatabase() {
        formModelList=new ArrayList<>();
        FormDatabase mDatabase=new FormDatabase(this);
        SQLiteDatabase db=mDatabase.getReadableDatabase();

        String query="select * from " + TABLE_NAME + ";";

        Cursor cursor=db.rawQuery(query, null);

        if(cursor != null) {
            if(cursor.getCount()>0) {
                while(cursor.moveToNext()) {
                    FormModel model=new FormModel();
                    model.setRollno(cursor.getString(0));
                    model.setStudentname(cursor.getString(1));
                    model.setStudentclass(cursor.getString(2));
                    model.setAddress(cursor.getString(3));
                    model.setContacts(cursor.getString(4));

                    formModelList.add(model);
                }
            }
        }

        db.close();


    }
}

