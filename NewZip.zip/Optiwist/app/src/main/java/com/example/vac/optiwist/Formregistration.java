package com.example.vac.optiwist;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import static com.example.vac.optiwist.Constants.*;
import com.example.vac.optiwist.FormDatabase;

public class Formregistration extends AppCompatActivity implements View.OnClickListener{
    private TextView rollnoTextView,studentnameTextView,studentclassTextView,addressTextview,
    contactsTextview,genderTextview,hobbies;
    private EditText rollnoEditText,studentnameEditText,studentclassEditText,addressEditText,
    contactsEditText;
    private Button upload,add;
    private RadioButton male,female,others;
    private RadioGroup gender;
    private CheckBox football,bookreading,surfing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formregistration);
        rollnoTextView=(TextView)findViewById(R.id.rollnoTextView);
        studentnameTextView=(TextView)findViewById(R.id.studentnameTextView);
        studentclassTextView=(TextView)findViewById(R.id.studentclassTextView);
        addressTextview=(TextView)findViewById(R.id.addressTextView);
        contactsTextview=(TextView)findViewById(R.id.contactsTextView);
        genderTextview=(TextView)findViewById(R.id.genderTextView);
        hobbies=(TextView)findViewById(R.id.hobbies);
        rollnoEditText=(EditText)findViewById(R.id.rollnoEditText);
        studentnameEditText=(EditText)findViewById(R.id.studentnameEditText);
        studentclassEditText=(EditText)findViewById(R.id.studentclassEditText);
        addressEditText=(EditText)findViewById(R.id.addressEditText);
        contactsEditText=(EditText)findViewById(R.id.contactsEditText);
        upload=(Button)findViewById(R.id.upload);
        add=(Button)findViewById(R.id.add);
        gender=(RadioGroup)findViewById(R.id.gender);
        male=(RadioButton)findViewById(R.id.male);
        female=(RadioButton)findViewById(R.id.female);
        others=(RadioButton)findViewById(R.id.others);
        football=(CheckBox)findViewById(R.id.football);
        bookreading=(CheckBox)findViewById(R.id.bookreading);
        surfing=(CheckBox)findViewById(R.id.surfing);
        upload.setOnClickListener(this);
        add.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.upload:
                rollnoEditText.setError(null);
                studentnameEditText.setError(null);
                studentclassEditText.setError(null);
                addressEditText.setError(null);
                contactsEditText.setError(null);
                if(TextUtils.isEmpty(rollnoEditText.getText())){
                    rollnoEditText.setError("Please enter your rollno");
                }else if(TextUtils.isEmpty(studentnameEditText.getText())){
                    studentnameEditText.setError("Please enter your student name");
                }else if(TextUtils.isEmpty(addressEditText.getText())){
                    addressEditText.setError("Please enter your address");
                }else if(TextUtils.isEmpty(contactsEditText.getText())){
                    contactsEditText.setError("Please enter your contact number");
                }else if(contactsEditText.getText().toString().length()<10){
                    contactsEditText.setError("Please enter a valid contact number");
                }else {
                    goToPhoto();
                    goToADDVALUESTODATABASE();
                }break;
            case R.id.add:
                goToList();
        }

    }

    private void goToADDVALUESTODATABASE() {
        FormDatabase mDatabase = new FormDatabase(this);
        SQLiteDatabase db = mDatabase.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ROLLNO, rollnoEditText.getText().toString());
        values.put(STUDENTNAME, studentnameEditText.getText().toString());
        values.put(STUDENTCLASS, studentclassEditText.getText().toString());
        values.put(ADDRESS, addressEditText.getText().toString());
        values.put(CONTACTS, contactsEditText.getText().toString());
        db.insertOrThrow (TABLE_NAME,null, values);
        db.close();
    }

    private void goToList() {
        Intent intent=new Intent(this,DetaillList.class);
        startActivity(intent);
    }

    private void goToPhoto() {
    }
}
