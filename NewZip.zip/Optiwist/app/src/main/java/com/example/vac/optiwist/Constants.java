package com.example.vac.optiwist;

/**
 * Created by vac on 8/27/2016.
 */
public class Constants {
    public static final String DATABASE_NAME=("myDatabase.db");
    public static final String TABLE_NAME=("form_table");
    public static final String ROLLNO=("rollno");
    public static final String STUDENTNAME=("studentname");
    public static final String STUDENTCLASS=("studentclass");
    public static final String ADDRESS=("address");
    public static final String CONTACTS=("contacts");
    public static final int DATABASE_VERSION=1;

}
